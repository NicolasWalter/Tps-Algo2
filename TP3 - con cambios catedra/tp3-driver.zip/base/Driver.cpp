#include "Driver.h"

namespace aed2 {

Driver::Driver() 
{
    // TODO
	assert(false);
}

Driver::~Driver()
{
    // TODO
	assert(false);
}


/// Generadores del Campus

void  Driver::comenzarRastrillaje(const Dicc<Agente,Posicion>& d)
{
    // TODO
	assert(false);
}


void Driver::crearCampus(Nat ancho, Nat alto)
{
    // TODO
	assert(false);
}

void Driver::agregarObstaculo(Posicion p)
{
    // TODO
	assert(false);
}


/// Observadores del Campus

Nat Driver::filas() const
{
    // TODO
	assert(false);
}

Nat Driver::columnas() const
{
    // TODO
	assert(false);
}

bool Driver::ocupada(Posicion p) const
{
    // TODO
	assert(false);
}


/// Generadores de CampusSeguro

void Driver::ingresarEstudiante(Nombre n, Posicion p)
{
    // TODO
	assert(false);
}

void Driver::ingresarHippie(Nombre n, Posicion p)
{
    // TODO
	assert(false);
}

void Driver::moverEstudiante(Nombre n, Direccion d)
{
    // TODO
	assert(false);
}

void Driver::moverHippie(Nombre n)
{
    // TODO
	assert(false);
}

void Driver::moverAgente(Agente pl)
{
    // TODO
	assert(false);
}


/// Observadores de CampusSeguro

Nombre Driver::iesimoEstudiante(Nat i) const
{
    // TODO
	assert(false);
}

Nombre Driver::iesimoHippie(Nat i) const
{
    // TODO
	assert(false);
}

Nat Driver::iesimoAgente(Nat i) const
{
    // TODO
	assert(false);
}


Posicion Driver::posEstudianteYHippie(Nombre n) const
{
    // TODO
	assert(false);
}

Posicion Driver::posAgente(Agente pl) const
{
    // TODO
	assert(false);
}

Nat Driver::cantSanciones(Agente pl) const
{
    // TODO
	assert(false);
}

Nat Driver::cantHippiesAtrapados(Agente pl) const
{
    // TODO
	assert(false);
}


/// Otras operaciones de CampusSeguro

Agente Driver::masVigilante() const
{
    // TODO
	assert(false);
}

const Conj<Agente>& Driver::conMismasSanciones(Agente a) const
{
    // TODO
	assert(false);
}

const Conj<Agente>& Driver::conKSanciones(Nat k)
{
    // TODO
	assert(false);
}


} // namespace aed2

